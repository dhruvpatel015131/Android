import 'package:flutter/material.dart';
import 'package:practical_three_api/gender.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Flutter Gender Prediction',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Gender Prediction'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late Future<Gender> gender;
  final nameController = TextEditingController();
  bool _validate = false;
  String genderOutput = "";
  String probOutput = "";
  Future<Gender> getOutput(String name) async {
    final response = await http.get(Uri.parse("https://api.genderize.io/?name=${name.toLowerCase().trim()}"));
    if (response.statusCode == 200) {
      // ignore_for_file: avoid_print
      print(jsonDecode(response.body));
      setState(() {
        genderOutput = "Gender: ${jsonDecode(response.body)["gender"].toString()}";
        probOutput = "Probability: ${jsonDecode(response.body)["probability"]}";
      });
      return Gender.fromJson(jsonDecode(response.body));
    }
    else {
      print("Failed to load data");
      throw Exception('Failed to load data');
    }
  }
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //title: Text(widget.title),
      ),
      body: Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child: Container(
          alignment: Alignment.center,
          color: Colors.white,
          margin: const EdgeInsets.only(left: 20.0, right: 20.0),
          child: Column(
            children: <Widget>[
              const Text(
                'Gender Prediction',
                style: TextStyle(fontSize: 28.0),
              ),
              TextField(
                controller: nameController,
                style: const TextStyle(fontSize: 20.0),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  labelText: 'Enter Your Name',
                  hintText: 'Enter Your Name',
                  errorText: _validate? "Can't be empty" :null,
                ),
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.amber,
                    textStyle: const TextStyle(
                        color: Colors.black,
                        fontSize: 20,
                        fontStyle: FontStyle.normal),
                  ),
                  onPressed: () {
                    setState(() {
                      _validate = nameController.text.isEmpty;

                      if(_validate == false)
                        {
                          gender = getOutput(nameController.text);
                        }
                    });

                  },
                  child: const Text(
                      'Predict')),
              Text(
                genderOutput,
                style: const TextStyle(fontSize: 20.0),
              ),
              Text(
                probOutput,
                style: const TextStyle(fontSize: 20.0),
              ),
            ],
          ),
        ),
      ),
    );
  }
  }
