package com.example.practical_three_api;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
